﻿# Specify the folder path and the output file path
$folderPath = "C:\Data\Hiep-LHS\Test"
$outputFilePath = "C:\Data\Hiep-LHS\File.txt"

# Get all files in the folder
$files = Get-ChildItem -Path $folderPath -File

# Loop through each file and write its content to the output file
foreach ($file in $files) {
    # Read the content of the file
    $fileContent = Get-Content -Path $file.FullName
    
    # Write the content to the output file
    $fileContent | Add-Content -Path $outputFilePath
}

# Output a message indicating the process is complete
Write-Output "All file contents have been written to $outputFilePath"